   // Evento para calcular a soma dos números
   $('#SOMAR-NUMEROS').click(function() {
    // Obter os valores dos inputs e convertê-los para números
    var num1 = parseFloat($('#input-primeiro-numero').val());
    var num2 = parseFloat($('#input-segundo-numero').val());

    // Verificar se os valores são números válidos
    if (!isNaN(num1) && !isNaN(num2)) {
        var soma = num1 + num2;
        alert('A soma dos números é: ' + soma);
    } else {
        alert('Por favor, insira números válidos.');
    }
})

$('#limpar').click(function() {
    $('#input-primeiro-numero').val('');
    $('#input-segundo-numero').val('');
});

